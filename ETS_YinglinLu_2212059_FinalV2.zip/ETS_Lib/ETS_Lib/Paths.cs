﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETS_Lib
{
    public static class Paths
    {
        public const string FILEPATH = @".\txtFile\donors.txt";


    }
}
